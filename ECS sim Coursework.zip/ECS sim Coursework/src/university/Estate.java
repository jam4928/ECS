package university;

import facilities.Facility;
import facilities.buildings.Hall;
import facilities.buildings.Lab;
import facilities.buildings.Theatre;
import java.util.ArrayList;


public class Estate{
    public ArrayList<Facility> facilities;
    public Estate() {
        this.facilities = new ArrayList<>();
    }
    public Facility[] getFacilities() {
        for (int i = 0; i < facilities.size(); i++){
            Facility[] arrayFacility = facilities.toArray(new Facility[i]);
            System.out.println("Array added"+arrayFacility);
        }
        return facilities.toArray(new Facility[0]);
    }
    public Facility addFacility(String type, String name) {
        Facility facility;
        if (type == "Hall") {
            facility = new Hall(name);
            this.facilities.add(facility);
            System.out.println("Facility added " + name + " Type : " + type);
            return facility;
        } else if (type == "Lab") {
            facility = new Lab(name);
            this.facilities.add(facility);
            System.out.println("Facility added " + name + " Type : " + type);
            return facility;
        } else if (type == "Theatre") {
            facility = new Theatre(name);
            this.facilities.add(facility);
            System.out.println("Facility added " + name + " Type : " + type);
            return facility;
        } else return null;
    }
    public float getMaintenanceCost(){
        float maintenanceCost = 0.0f;
        for (int i = 0; i < facilities.size(); i++){
            if (facilities.get(i) instanceof Hall){
                maintenanceCost = maintenanceCost + ((Hall) facilities.get(i)).getCapacity();
            } else if (facilities.get(i) instanceof Lab){
                maintenanceCost = maintenanceCost + ((Lab) facilities.get(i)).getCapacity();
            } else if (facilities.get(i) instanceof Theatre){
                maintenanceCost = maintenanceCost + ((Theatre) facilities.get(i)).getCapacity();
            }
        }
        System.out.println("Total Maintenance cost: $"+maintenanceCost*0.1f);
        return maintenanceCost*0.1f;
    }
    public int getNumberOfStudents(){
        int hallStudent = 0;
        int labStudent = 0;
        int theatreStudent = 0;
        for (int i = 0; i < facilities.size(); i++){
            if (facilities.get(i) instanceof Hall){
                hallStudent = hallStudent + ((Hall) facilities.get(i)).getCapacity();
            } else if (facilities.get(i) instanceof Lab){
                labStudent = labStudent + ((Lab) facilities.get(i)).getCapacity();
            } else if (facilities.get(i) instanceof Theatre){
                theatreStudent = theatreStudent + ((Theatre) facilities.get(i)).getCapacity();
            }
        }
        int minimalStudents = Math.min(Math.min(hallStudent, labStudent), theatreStudent);
        System.out.println("Total students: "+minimalStudents);
        return minimalStudents;
    }
}
