package university;

import java.util.HashMap;
import java.util.Iterator;

public class HumanResource {
    public HashMap<Staff, Float> staffSalary;
    public HumanResource(){
        staffSalary = new HashMap<>();
    }
    public void addStaff(Staff staff){
        float salary = (float) (Math.random() * (staff.skill*0.095) + (staff.skill*0.105));
        staffSalary.put(staff, salary);
        System.out.println("Staff added : "+staff.name+" Salary : $"+salary);
    }
    public void removeStaff(Staff staff){
        staffSalary.remove(staff);
    }
    public Iterator<Staff> getStaff(){
        return staffSalary.keySet().iterator();
    }
    public Float getTotalSalary(){
        float totalSalary = 0;
        for (Float salary : staffSalary.values()) {
            totalSalary = totalSalary + salary;
        }
        System.out.println("Total Salary : $"+totalSalary);
        return totalSalary;
    }
}
