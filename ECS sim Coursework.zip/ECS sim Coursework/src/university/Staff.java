package university;

public class Staff {
    public String name;
    int skill;
    int yearsOfTeaching = 0;
    int stamina = 100;
    public Staff(String name, int skill){
        this.name = name;
        this.skill = skill;
    }
    public String getStaffname(){
        return this.name;
    }
    public int getSkill(){
        return this.skill;
    }
    public int getStamina(){
        return this.stamina;
    }
    public void getStaffinfo(){
        System.out.println("Name : "+this.name);
        System.out.println("Skill : "+this.skill);
        System.out.println("Years of teaching : "+this.yearsOfTeaching);
        System.out.println("Stamina : "+this.stamina);
    }
    public int instruct(int numberOfStudents){
        int reputation = (100*this.skill)/(100+numberOfStudents);
        if (this.skill<100){
            this.skill = this.skill + 1;
        }
        this.stamina = (int) (this.stamina - (java.lang.Math.ceil(numberOfStudents/(20+skill)))*20);
        System.out.println(this.name+" finished teaching "+numberOfStudents+" students");
        System.out.println("Stamina :"+this.stamina+" Reputation increased by "+reputation);
        return reputation;
    }
    public void replenishStamina(){
        if (this.stamina <= 80){
            this.stamina = this.stamina + 20;
        } else stamina = 100;
        System.out.println(this.name+" took a rest and stamina replenished to "+this.stamina);
    }
    public void increaseYearsOfTeaching(){
        this.yearsOfTeaching = this.yearsOfTeaching + 1;
        System.out.println(this.name+" years of teaching is now increased to "+this.yearsOfTeaching);
    }
    public int getYearsOfTeaching(){
        return this.yearsOfTeaching;
    }
}
