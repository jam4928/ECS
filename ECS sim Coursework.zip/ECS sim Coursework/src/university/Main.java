package university;

import java.util.Iterator;

public class Main {
    public static void main(String[] args) {
        Staff staff1 = new Staff("John", 30);
        Staff staff2 = new Staff("Peter",50);
        Staff staff3 = new Staff("Mary", 40);
        staff1.getStaffinfo();
        staff1.getStaffname();
        staff1.instruct(20);
        staff1.instruct(60);
        staff1.instruct(200);
        staff1.replenishStamina();
        staff1.replenishStamina();
        staff1.replenishStamina();
        staff1.replenishStamina();
        staff1.replenishStamina();
        staff1.increaseYearsOfTeaching();
        staff1.getStaffinfo();
        HumanResource staffs = new HumanResource();
        staffs.addStaff(staff1);
        staffs.addStaff(staff2);
        staffs.addStaff(staff3);
        staffs.getTotalSalary();
        Iterator<Staff> staffIterator = staffs.getStaff();
        while (staffIterator.hasNext()) {
            Staff staff = staffIterator.next();
            System.out.println("Staff : "+staff.name);
        }
    }
}