package university;

import facilities.Facility;
import facilities.buildings.Building;
import facilities.buildings.Hall;
import facilities.buildings.Lab;
import facilities.buildings.Theatre;

public class University {
    public float budget = 1000;
    public Estate estate = new Estate();
    public int reputation = 0;
    public HumanResource humanResource = new HumanResource();

    public University(int funding) {
        budget = (float) funding;
    }

    public Facility build(String type, String name) {
        int baseCost = 0;
        Facility newFacility = estate.addFacility(type, name);
        for (int i = 0; i < estate.facilities.size(); i++) {
            if (newFacility instanceof Hall) {
                baseCost = ((Hall) newFacility).getBaseCost();
            } else if (newFacility instanceof Lab) {
                baseCost = ((Lab) newFacility).getBaseCost();
            } else if (newFacility instanceof Theatre) {
                baseCost = ((Theatre) newFacility).getBaseCost();
            } else return null;
        }
        budget = budget - baseCost;
        reputation = reputation + 100;
        return newFacility;
    }
    public void upgrade(Building building) throws Exception {
        int upgradeCost = building.getUpgradeCost();
        if (upgradeCost > budget) {
            throw new Exception("Not enough moeny");
        }
        if (building.getmaxLevel() < building.getLevel()) {
            throw new Exception("Building have reached max level");
        }
        if (!estate.facilities.contains(building)){
            throw new Exception("Building is not in the university");
        }
        if (upgradeCost == -1){
            throw new Exception("Building have reached max level");
        }
        System.out.println("Cost of upgrading :$"+upgradeCost);
        building.increaseLevel();
        budget = budget - upgradeCost;
        reputation = reputation + 50;
    }
    public int upgradeCost(Building building){
        return building.getUpgradeCost();
    }
    public float getBudget(){
        return budget;
    }
    public int getReputation(){
        return reputation;
    }
}
