import facilities.Facility;
import facilities.buildings.Building;
import university.Staff;
import university.University;
import java.io.BufferedReader ;
import java.io.FileNotFoundException;
import java.io.FileReader ;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;


public class EcsSim {

    ArrayList<Staff> staffMarket;
    University university;
    int uninstructedStudents = 0; //store the students that are not instructed yet
    int instructedStudents = 0; //for storing students instructed
    int HallCounter = 0; //for counting halls built
    int LabCounter = 0; //for counting labs built
    int TheatreCounter = 0; // for counting theatre built
    int staffCounter = 0; // for counting staffs
    int workingStaff = 0; //for couunting amount of staff in university


    //constructor of EcsSim to create new university
    public EcsSim(int budget) {
        staffMarket = new ArrayList<>(134);
        university = new University(budget);
    }
    //method to add the staff.txt names and skills to the arraylist staffmarket
    public void addstaffMarket(String filename){
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(filename));
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("[()]");
                    if (parts.length == 2) {
                        String name = parts[0].trim();
                        int skill = Integer.parseInt(parts[1].trim());
                        Staff staff = new Staff(name, skill);
                        this.staffMarket.add(staff);
                    } else if (parts.length == 3) {
                        String name = parts[0].trim() + parts[1].trim();
                        int skill = Integer.parseInt(parts[2].trim());
                        Staff staff = new Staff(name, skill);
                        this.staffMarket.add(staff);
                    } else System.err.println("text format is wrong");
                }
            } catch (IOException e) {
                System.err.println("error reading input file" + filename);
            }
        } catch (FileNotFoundException e) {
            System.err.println("file not found"+filename);
        }
    }
    public void simulate() {
        // part 1
        if (this.university.budget > 0) {
            int buildingmoney = (int) (this.university.budget * 0.2); //10% of the original budget used for building
            int upgradingmoney = (int) (this.university.budget * 0.3); //30% used to upgrade
            int buildingmoneyspent = 0; //calculate the money spent on buildings
            int upgradingmoneyspent = 0; //calculate the money spent on upgrading
            System.out.println("Original budget : $" + this.university.getBudget());
            //building buildings until the building budget is at the limit
            System.out.println("----------Building------------");
            while (buildingmoney >= 100 && buildingmoneyspent <= buildingmoney) {
                //skips building if the amount of money used on spending is less than 100 as cheapest building is 100
                //it makes sure that all types of buildings are balanced
                //1 building of each type is built at least
                if (this.university.budget > 100) {
                    if (HallCounter <= LabCounter && HallCounter <= TheatreCounter || HallCounter == 0) {
                        HallCounter = HallCounter + 1;
                        this.university.build("Hall", "Hall" + (HallCounter));
                        buildingmoneyspent = buildingmoneyspent + 100;
                    }
                }
                if (this.university.budget > 200) {
                    if (TheatreCounter <= HallCounter && TheatreCounter <= LabCounter || TheatreCounter == 0) {
                        TheatreCounter = TheatreCounter + 1;
                        this.university.build("Theatre", "Theatre" + (TheatreCounter));
                        buildingmoneyspent = buildingmoneyspent + 200;
                    }
                }
                if (this.university.budget > 300) {
                    if (LabCounter <= TheatreCounter && LabCounter <= HallCounter || LabCounter == 0) {
                        LabCounter = LabCounter + 1;
                        this.university.build("Lab", "Lab" + (LabCounter));
                        buildingmoneyspent = buildingmoneyspent + 300;
                    }
                }
                    System.out.println("Budget : " + this.university.getBudget());
            }
            System.out.println("----------Upgrading------------");
            //upgrade only starts when budget is over 5000 as it is too expensive to start
            //upgrading buildings until the building upgrade reaches the limit
            for (Facility facility : this.university.estate.facilities) {
                if (this.university.budget > 5000 && upgradingmoneyspent < upgradingmoney && this.university.getBudget() > this.university.upgradeCost((Building) facility)) {
                    try {
                        upgradingmoneyspent = upgradingmoneyspent + this.university.upgradeCost((Building) facility);
                        this.university.upgrade((Building) facility);
                        System.out.println("Budget : " + this.university.getBudget());
                    } catch (Exception e) {
                        System.err.println("Failed to upgrade");
                    }
                }
            }


            System.out.println("----------Hiring and teaching ------------");
            //increasing budget based on students
            uninstructedStudents = this.university.estate.getNumberOfStudents() - instructedStudents;
            int Budgetincrease = this.university.estate.getNumberOfStudents() * 10;
            this.university.budget = this.university.budget + Budgetincrease;
            System.out.println("Budget increased to $" + this.university.budget);

            //hiring staffs for every 10 students and instantly instructs 10 students
            //check the condition if the counter of staffs multiply by 10 is smaller than number of students
            //the uninstructed students must also be equal or higher than 10 as a staff will teach 10 students
            while (staffCounter < this.staffMarket.size() && workingStaff * 10 <= this.university.estate.getNumberOfStudents() && uninstructedStudents >= 10 && this.university.getBudget() > 0) {
                if (!this.staffMarket.isEmpty()) {
                    Staff newstaff = this.staffMarket.get(staffCounter);
                    System.out.println(staffCounter);
                    String name = newstaff.getStaffname(); // Assuming you have a getter method in your Staff class
                    int skill = newstaff.getSkill();
                    this.staffMarket.remove(staffCounter);
                    staffCounter = staffCounter + 1;
                    workingStaff = workingStaff + 1;
                    newstaff = new Staff(name, skill);
                    this.university.humanResource.addStaff(newstaff);
                    //staff that are hired instructs 10 students and adds the reputation gained
                    this.university.reputation = this.university.reputation + newstaff.instruct(10);
                    instructedStudents = instructedStudents + 10;
                    uninstructedStudents = uninstructedStudents - 10;
                }
            }
            System.out.println("Uninstructed students left " + uninstructedStudents);

            //increasing staff years of teaching
            System.out.println("----------Checking staff------------");
            Iterator<Staff> staffIterator = this.university.humanResource.getStaff();
            while (staffIterator.hasNext()) {
                Staff staff = staffIterator.next();
                System.out.println("Staff : " + staff.name);
                if (staff.getStamina() <= 0 || staff.getYearsOfTeaching() >= 30) {
                    staffIterator.remove();
                    this.university.humanResource.removeStaff(staff);
                    //removes the staff from the list and also add back the students that it were teaching
                    uninstructedStudents = uninstructedStudents + 10;
                    instructedStudents = instructedStudents - 10;
                    System.out.println("Staff have left");
                } else if ((float) staff.getStamina() / 100 < Math.random()) {
                    //gets random decimal number between 0 and 1,
                    // it compares to stamina where the stamina is converted to a decimal,
                    // if the random decimal is higher than the decimal of stamina,
                    // it removes staff
                    staffIterator.remove();
                    this.university.humanResource.removeStaff(staff);
                    uninstructedStudents = uninstructedStudents + 10;
                    instructedStudents = instructedStudents - 10;
                    workingStaff = workingStaff - 1;
                    System.out.println("Staff have left");
                } else {
                    staff.increaseYearsOfTeaching(); //increase years of teaching
                    staff.replenishStamina(); //replenish stamina
                }
            }

            System.out.println("----------End of year------------");
            //part 3
            this.university.budget = this.university.budget - this.university.estate.getMaintenanceCost();
            //paying the maintenance cost
            this.university.budget = this.university.budget - this.university.humanResource.getTotalSalary();
            //paying the salary
            this.university.reputation = this.university.reputation - uninstructedStudents;
            //decreasing reputation by 1 per uninstructed student

            System.out.println("----------Info------------");
            this.university.estate.getNumberOfStudents();
            System.out.println("Uninstructed students : "+uninstructedStudents);
            System.out.println("Total staff : "+this.university.humanResource.staffSalary.size());
            System.out.println("Reputation : " + this.university.getReputation());
            System.out.println("Budget : " + this.university.getBudget());
            System.out.println("Halls : " + HallCounter);
            System.out.println("Labs : " + LabCounter);
            System.out.println("Theatre : " + TheatreCounter);
            System.out.println("Total buildings : " + (HallCounter + LabCounter + TheatreCounter));
            System.out.println("----------------------");
        } else {
            System.out.println("University shut down because of bankruptcy");
        }
    }

    public void simulate(int years) {
        for (int i = 1; i <= years; i++) {
            System.out.println("-----------Year "+i+"-----------");
            simulate();
        }
        System.out.println("end");
    }

    public static void main(String[] args){
        //var filename = args[0];
        //int budget = Integer.parseInt(args[1]);
        //int years = Integer.parseInt(args[2]);
        var filename = "staff.txt";
        int budget = 2000;
        int years = 10;
        EcsSim simulation = new EcsSim(budget);
        simulation.addstaffMarket(filename);
        simulation.simulate(years);
    }
}

