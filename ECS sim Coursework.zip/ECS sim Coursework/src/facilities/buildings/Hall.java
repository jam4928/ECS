package facilities.buildings;


import facilities.Facility;

public class Hall extends Facility implements Building{
    int level = 1;
    int baseCost = 100;
    int maxlevel = 4;

    int baseCapacity = 6;

    public Hall(String name) {
        super(name);
    }
    public int getLevel(){
        return this.level;
    }
    public void increaseLevel(){
        if (this.level < this.maxlevel) {
            this.level = this.level + 1;
            System.out.println(this.getName() + " level is increased to " + this.getLevel());
        }
    }
    public int getUpgradeCost(){
        if (this.level < this.maxlevel) {
            return this.baseCost * (this.level + 1);
        } else return -1;
    }
    public int getCapacity(){
        int capacity;
        capacity = (int) (baseCapacity*Math.pow(2,this.level-1));
        return capacity;
    }
    public int getBaseCost(){
        return baseCost;
    }
    public int getmaxLevel(){
        return maxlevel;
    }
}
