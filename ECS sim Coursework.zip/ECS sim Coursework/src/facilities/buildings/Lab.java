package facilities.buildings;


import facilities.Facility;

public class Lab extends Facility implements Building{
    String name = "Lab";
    int level = 1;
    int maxlevel = 5;
    int baseCost = 300;
    int baseCapacity = 5;

    public Lab(String name) {
        super(name);
    }

    public int getLevel(){
        return this.level;
    }
    public void increaseLevel(){
        if (this.level < this.maxlevel) {
            this.level = this.level + 1;
            System.out.println(this.getName() + " level is increased to " + this.getLevel());
        }
    }
    public int getUpgradeCost(){
        if (this.level < this.maxlevel){
            return this.baseCost * (this.level + 1);
        } else return -1;
    }
    public int getCapacity(){
        int capacity;
        capacity = (int) (baseCapacity*Math.pow(2,this.level-1));
        return capacity;
    }
    public int getBaseCost(){
        return baseCost;
    }
    public int getmaxLevel(){
        return maxlevel;
    }
}
