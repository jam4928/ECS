package facilities;


public class Facility{
    public String name;
    public Facility(String name){
        this.name = name;
    }
    public String getName() {
        return name;
    }
}
